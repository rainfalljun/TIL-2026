const STORAGE_KEY = 'my-tasks';
const THEME_KEY   = 'my-tasks-theme';
const HISTORY_KEY = 'my-tasks-history'; // { "YYYY-MM-DD": { total, completed } }

const CATEGORY_META = {
  work:     { label: '💼 업무', badgeClass: 'badge-work' },
  personal: { label: '🏠 개인', badgeClass: 'badge-personal' },
  study:    { label: '📚 공부', badgeClass: 'badge-study' },
  faith:    { label: '🙏 신앙', badgeClass: 'badge-faith' },
  exercise: { label: '💪 운동', badgeClass: 'badge-exercise' },
  other:    { label: '📌 기타', badgeClass: 'badge-other' },
};

const CATEGORY_ORDER = { work: 0, personal: 1, study: 2, faith: 3, exercise: 4, other: 5 };
const PRIORITY_ORDER = { high: 0, medium: 1, low: 2 };
const DAY_LABELS     = ['일', '월', '화', '수', '목', '금', '토'];

// ── State ──────────────────────────────────────────────
let todos         = loadTodos();
let currentFilter = 'all';
let currentSort   = 'newest';
let currentSearch = '';

// ── DOM refs ───────────────────────────────────────────
const input          = document.getElementById('todo-input');
const categorySelect = document.getElementById('category-select');
const prioritySelect = document.getElementById('priority-select');
const dueDateInput   = document.getElementById('due-date-input');
const repeatCheck    = document.getElementById('repeat-check');
const searchInput    = document.getElementById('search-input');
const addBtn         = document.getElementById('add-btn');
const list           = document.getElementById('todo-list');
const emptyMsg       = document.getElementById('empty-msg');
const filterBtns     = document.querySelectorAll('.filter-btn');
const progressText   = document.getElementById('progress-text');
const progressPct    = document.getElementById('progress-pct');
const progressBar    = document.getElementById('progress-bar');
const themeToggle    = document.getElementById('theme-toggle');
const clearBtn       = document.getElementById('clear-btn');
const exportBtn      = document.getElementById('export-btn');
const importInput    = document.getElementById('import-input');
const sortSelect     = document.getElementById('sort-select');

// ── LocalStorage ───────────────────────────────────────
function loadTodos() {
  try   { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
  catch { return []; }
}

function saveTodos() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(todos));
  updateDailySnapshot();
}

// ── Daily Snapshot ─────────────────────────────────────
function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function updateDailySnapshot() {
  try {
    const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '{}');
    history[todayStr()] = {
      total:     todos.length,
      completed: todos.filter(t => t.completed).length,
    };
    // 최근 30일치만 보관
    const keys = Object.keys(history).sort();
    keys.slice(0, Math.max(0, keys.length - 30)).forEach(k => delete history[k]);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  } catch { /* 무시 */ }
}

function loadHistory() {
  try   { return JSON.parse(localStorage.getItem(HISTORY_KEY) || '{}'); }
  catch { return {}; }
}

// ── Repeat Reset ───────────────────────────────────────
// 앱 시작 시 "매일 반복" 항목을 오늘 날짜로 초기화
function resetRepeatTodos() {
  const today = todayStr();
  let changed = false;
  todos.forEach(todo => {
    if (todo.repeat && todo.lastResetDate !== today) {
      todo.completed    = false;
      todo.lastResetDate = today;
      changed = true;
    }
  });
  if (changed) saveTodos();
}

// ── Theme ──────────────────────────────────────────────
function loadTheme() {
  applyTheme(localStorage.getItem(THEME_KEY) || 'light');
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  themeToggle.textContent = theme === 'dark' ? '☀️' : '🌙';
  localStorage.setItem(THEME_KEY, theme);
}

function toggleTheme() {
  const cur = document.documentElement.getAttribute('data-theme');
  applyTheme(cur === 'dark' ? 'light' : 'dark');
}

// ── D-day ──────────────────────────────────────────────
function getDdayInfo(dueDateStr) {
  if (!dueDateStr) return null;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const due   = new Date(dueDateStr); due.setHours(0, 0, 0, 0);
  const diff  = Math.round((due - today) / 86400000);

  if (diff === 0) return { text: 'D-day',       cls: 'dday-today' };
  if (diff  >  0) return { text: `D-${diff}`,   cls: diff <= 3 ? 'dday-soon' : 'dday-normal' };
  return             { text: `${-diff}일 지남`,  cls: 'dday-over' };
}

// ── CRUD ───────────────────────────────────────────────
function addTodo(title, category, priority, dueDate, repeat) {
  todos.unshift({
    id:            crypto.randomUUID(),
    title:         title.trim(),
    category,
    priority,
    dueDate:       dueDate || null,
    repeat,
    lastResetDate: repeat ? todayStr() : null,
    completed:     false,
    createdAt:     new Date().toISOString(),
  });
  saveTodos();
  render();
}

function toggleTodo(id) {
  const todo = todos.find(t => t.id === id);
  if (todo) { todo.completed = !todo.completed; saveTodos(); render(); }
}

function deleteTodo(id) {
  todos = todos.filter(t => t.id !== id);
  saveTodos();
  render();
}

function updateTodo(id, fields) {
  const todo = todos.find(t => t.id === id);
  if (!todo) return;
  Object.assign(todo, fields);
  saveTodos();
  render();
}

function clearCompleted() {
  const count = todos.filter(t => t.completed).length;
  if (count === 0) { showToast('삭제할 완료 항목이 없어요'); return; }
  todos = todos.filter(t => !t.completed);
  saveTodos();
  render();
  showToast(`완료된 항목 ${count}개를 삭제했어요`);
}

// ── Sort ───────────────────────────────────────────────
function getSorted(arr) {
  const copy = [...arr];
  switch (currentSort) {
    case 'oldest':
      return copy.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    case 'priority':
      return copy.sort((a, b) =>
        (PRIORITY_ORDER[a.priority] ?? 1) - (PRIORITY_ORDER[b.priority] ?? 1));
    case 'duedate':
      return copy.sort((a, b) => {
        if (!a.dueDate && !b.dueDate) return 0;
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return a.dueDate.localeCompare(b.dueDate);
      });
    case 'category':
      return copy.sort((a, b) =>
        (CATEGORY_ORDER[a.category] ?? 9) - (CATEGORY_ORDER[b.category] ?? 9));
    case 'completed':
      return copy.sort((a, b) => Number(b.completed) - Number(a.completed));
    default: // newest
      return copy.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }
}

// ── Progress ───────────────────────────────────────────
function updateProgress() {
  const total     = todos.length;
  const completed = todos.filter(t => t.completed).length;
  const pct       = total === 0 ? 0 : Math.round((completed / total) * 100);

  progressText.textContent = `완료 ${completed} / 전체 ${total}`;
  progressPct.textContent  = `${pct}%`;
  progressBar.style.width  = `${pct}%`;
  progressBar.classList.toggle('complete', pct === 100 && total > 0);
}

// ── Render ─────────────────────────────────────────────
function render() {
  let filtered = todos;
  if (currentFilter !== 'all') {
    filtered = filtered.filter(t => t.category === currentFilter);
  }
  if (currentSearch) {
    const q = currentSearch.toLowerCase();
    filtered = filtered.filter(t => t.title.toLowerCase().includes(q));
  }
  const sorted = getSorted(filtered);

  list.innerHTML = '';
  emptyMsg.style.display = sorted.length === 0 ? 'block' : 'none';
  emptyMsg.textContent   = todos.length === 0
    ? '아직 할 일이 없어요 ✅'
    : currentSearch
      ? `"${escapeHtml(currentSearch)}" 검색 결과가 없어요`
      : '해당 카테고리의 할 일이 없어요';

  const fragment = document.createDocumentFragment();

  sorted.forEach(todo => {
    const meta     = CATEGORY_META[todo.category] || CATEGORY_META.other;
    const ddayInfo = getDdayInfo(todo.dueDate);
    const li       = document.createElement('li');

    li.className  = `todo-item priority-${todo.priority || 'medium'}${todo.completed ? ' completed' : ''}`;
    li.dataset.id = todo.id;

    const ddayHtml   = ddayInfo
      ? `<span class="dday-chip ${ddayInfo.cls}">${ddayInfo.text}</span>` : '';
    const repeatHtml = todo.repeat
      ? `<span class="repeat-icon" title="매일 반복">🔁</span>` : '';

    li.innerHTML = `
      <input type="checkbox" ${todo.completed ? 'checked' : ''} aria-label="완료 표시" />
      <span class="todo-title">${escapeHtml(todo.title)}</span>
      ${repeatHtml}
      ${ddayHtml}
      <span class="category-badge ${meta.badgeClass}">${meta.label}</span>
      <button class="edit-btn" aria-label="수정">✏️</button>
      <button class="delete-btn" aria-label="삭제">🗑</button>
    `;
    fragment.appendChild(li);
  });

  list.appendChild(fragment);
  updateProgress();
  renderWeeklyChart();
  renderCategoryStats();
}

// ── Inline Edit ────────────────────────────────────────
function startEdit(li) {
  const id   = li.dataset.id;
  const todo = todos.find(t => t.id === id);
  if (!todo) return;

  li.classList.add('editing');

  // 제목
  const editInput = document.createElement('input');
  editInput.type      = 'text';
  editInput.className = 'edit-input';
  editInput.value     = todo.title;

  // 카테고리
  const editCat = document.createElement('select');
  editCat.className = 'edit-select';
  Object.entries(CATEGORY_META).forEach(([val, m]) => {
    const o = document.createElement('option');
    o.value = val; o.textContent = m.label;
    if (val === todo.category) o.selected = true;
    editCat.appendChild(o);
  });

  // 우선순위
  const editPri = document.createElement('select');
  editPri.className = 'edit-select';
  [['high','🔴 높음'],['medium','🟡 보통'],['low','🟢 낮음']].forEach(([val, label]) => {
    const o = document.createElement('option');
    o.value = val; o.textContent = label;
    if (val === (todo.priority || 'medium')) o.selected = true;
    editPri.appendChild(o);
  });

  // 마감일
  const editDue = document.createElement('input');
  editDue.type      = 'date';
  editDue.className = 'edit-date';
  editDue.value     = todo.dueDate || '';

  const editBtn = li.querySelector('.edit-btn');
  li.insertBefore(editInput, editBtn);
  li.insertBefore(editCat,   editBtn);
  li.insertBefore(editPri,   editBtn);
  li.insertBefore(editDue,   editBtn);
  editInput.focus();
  editInput.select();

  function commitEdit() {
    const newTitle = editInput.value.trim();
    if (newTitle) {
      updateTodo(id, {
        title:    newTitle,
        category: editCat.value,
        priority: editPri.value,
        dueDate:  editDue.value || null,
      });
    } else render(); // 빈 제목이면 취소
  }

  editInput.addEventListener('keydown', e => {
    if (e.key === 'Enter')  { e.preventDefault(); commitEdit(); }
    if (e.key === 'Escape') render();
  });

  function handleBlur() {
    setTimeout(() => { if (!li.contains(document.activeElement)) commitEdit(); }, 150);
  }
  [editInput, editCat, editPri, editDue].forEach(el => el.addEventListener('blur', handleBlur));
}

// ── Weekly Chart ───────────────────────────────────────
function renderWeeklyChart() {
  const chart   = document.getElementById('weekly-chart');
  const history = loadHistory();
  const today   = new Date();

  // 오늘 스냅샷 실시간 반영
  history[todayStr()] = {
    total:     todos.length,
    completed: todos.filter(t => t.completed).length,
  };

  const days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() - (6 - i));
    return d;
  });

  chart.innerHTML = '';
  const frag = document.createDocumentFragment();

  days.forEach(date => {
    const key     = date.toISOString().slice(0, 10);
    const isToday = key === todayStr();
    const snap    = history[key];
    const pct     = snap && snap.total > 0
      ? Math.round((snap.completed / snap.total) * 100) : null;

    const col = document.createElement('div');
    col.className = 'day-col';

    const pctEl = document.createElement('div');
    pctEl.className   = 'bar-pct';
    pctEl.textContent = pct !== null ? `${pct}%` : '';

    const barWrap = document.createElement('div');
    barWrap.className = 'bar-wrap';

    const bar = document.createElement('div');
    bar.className    = 'bar' + (isToday ? ' today' : '') + (pct === null ? ' no-data' : '');
    bar.style.height = pct !== null ? `${pct}%` : '3px';
    bar.dataset.tip  = isToday
      ? `오늘 · ${snap ? `${snap.completed}/${snap.total}개` : '0개'}`
      : snap ? `${snap.completed}/${snap.total}개` : '데이터 없음';

    barWrap.appendChild(bar);

    const dayEl = document.createElement('div');
    dayEl.className   = 'bar-day' + (isToday ? ' today-label' : '');
    dayEl.textContent = isToday ? '오늘' : DAY_LABELS[date.getDay()];

    col.appendChild(pctEl);
    col.appendChild(barWrap);
    col.appendChild(dayEl);
    frag.appendChild(col);
  });

  chart.appendChild(frag);
  renderBestDay(history);
}

function renderBestDay(history) {
  const el = document.getElementById('best-day');
  if (!el) return;

  const entries = Object.entries(history)
    .filter(([, v]) => v.total > 0)
    .map(([k, v]) => ({ date: k, pct: Math.round(v.completed / v.total * 100) }));

  if (entries.length === 0) { el.textContent = ''; return; }

  const best    = entries.reduce((a, b) => a.pct >= b.pct ? a : b);
  const dayName = DAY_LABELS[new Date(best.date + 'T12:00:00').getDay()];
  el.textContent = `🏆 최고 달성일: ${best.date} (${dayName}요일) ${best.pct}%`;
}

// ── Category Stats ─────────────────────────────────────
function renderCategoryStats() {
  const el = document.getElementById('category-stats');
  if (!el) return;

  el.innerHTML = '';
  const frag = document.createDocumentFragment();

  Object.entries(CATEGORY_META).forEach(([key, meta]) => {
    const items = todos.filter(t => t.category === key);
    if (items.length === 0) return;

    const done = items.filter(t => t.completed).length;
    const pct  = Math.round((done / items.length) * 100);
    const barCls = meta.badgeClass.replace('badge-', 'bar-cat-');

    const row = document.createElement('div');
    row.className = 'cat-stat-row';
    row.innerHTML = `
      <span class="cat-stat-label">${meta.label}</span>
      <div class="cat-stat-bar-wrap">
        <div class="cat-stat-bar ${barCls}" style="width:${pct}%"></div>
      </div>
      <span class="cat-stat-pct">${done}/${items.length} (${pct}%)</span>
    `;
    frag.appendChild(row);
  });

  el.appendChild(frag);
}

// ── Export / Import ────────────────────────────────────
function exportData() {
  if (todos.length === 0) { showToast('내보낼 데이터가 없어요'); return; }
  const blob = new Blob([JSON.stringify(todos, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = Object.assign(document.createElement('a'), {
    href: url, download: `my-tasks-${todayStr()}.json`,
  });
  a.click();
  URL.revokeObjectURL(url);
  showToast(`${todos.length}개 항목을 내보냈어요`);
}

function importData(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      if (!Array.isArray(data)) throw new Error();
      if (!data.every(t => t.id && typeof t.title === 'string')) throw new Error();

      data.forEach(t => {
        if (!t.category) t.category = 'other';
        if (!t.priority) t.priority = 'medium';
      });

      const ids      = new Set(todos.map(t => t.id));
      const newItems = data.filter(t => !ids.has(t.id));
      todos = [...newItems, ...todos];
      saveTodos();
      render();
      showToast(`${newItems.length}개 항목을 가져왔어요`);
    } catch {
      showToast('올바른 JSON 파일이 아니에요');
    }
    importInput.value = '';
  };
  reader.readAsText(file);
}

// ── Toast ──────────────────────────────────────────────
let toastTimer;
function showToast(msg) {
  let toast = document.querySelector('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
}

// ── Keyboard Shortcuts ─────────────────────────────────
document.addEventListener('keydown', e => {
  if (!e.altKey) return;

  if (e.key === 'n' || e.key === 'N') {
    e.preventDefault();
    input.focus();
    input.select();
    return;
  }

  const filterMap = {
    '1': 'all', '2': 'work', '3': 'personal',
    '4': 'study', '5': 'faith', '6': 'exercise', '7': 'other',
  };
  if (filterMap[e.key]) { e.preventDefault(); setFilter(filterMap[e.key]); }
});

function setFilter(filter) {
  currentFilter = filter;
  filterBtns.forEach(b => b.classList.toggle('active', b.dataset.filter === filter));
  render();
}

// ── Events ─────────────────────────────────────────────
addBtn.addEventListener('click', handleAdd);
input.addEventListener('keydown', e => { if (e.key === 'Enter') handleAdd(); });

searchInput.addEventListener('input', () => {
  currentSearch = searchInput.value.trim();
  render();
});

themeToggle.addEventListener('click', toggleTheme);
clearBtn.addEventListener('click', clearCompleted);
exportBtn.addEventListener('click', exportData);
importInput.addEventListener('change', e => importData(e.target.files[0]));
sortSelect.addEventListener('change', () => { currentSort = sortSelect.value; render(); });
filterBtns.forEach(btn => btn.addEventListener('click', () => setFilter(btn.dataset.filter)));

list.addEventListener('click', e => {
  const li = e.target.closest('.todo-item');
  if (!li) return;
  const id = li.dataset.id;
  if      (e.target.matches('input[type="checkbox"]')) toggleTodo(id);
  else if (e.target.matches('.edit-btn'))              startEdit(li);
  else if (e.target.matches('.delete-btn'))            deleteTodo(id);
});

function handleAdd() {
  const title    = input.value.trim();
  const category = categorySelect.value;
  const priority = prioritySelect.value;
  const dueDate  = dueDateInput.value || null;
  const repeat   = repeatCheck.checked;

  if (!title) { shakeInput(); return; }

  addTodo(title, category, priority, dueDate, repeat);
  input.value         = '';
  dueDateInput.value  = '';
  repeatCheck.checked = false;
  input.focus();
}

function shakeInput() {
  input.classList.remove('shake');
  void input.offsetWidth;
  input.classList.add('shake');
  input.addEventListener('animationend', () => input.classList.remove('shake'), { once: true });
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function renderKeyboardHint() {
  const hint = document.createElement('p');
  hint.className   = 'kbd-hint';
  hint.textContent = 'Alt+N: 새 할 일  ·  Alt+1~7: 필터 전환';
  document.querySelector('.container').appendChild(hint);
}

// ── Init ───────────────────────────────────────────────
loadTheme();
resetRepeatTodos();
render();
renderKeyboardHint();
